from odoo import models, fields, api, _
from odoo.exceptions import UserError


class CustomerStatement(models.Model):
    _name = 'customer.statement'
    _description = '客户对账单'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date_statement desc, id desc'

    name = fields.Char(
        string='对账单号',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('新建'),
    )
    date_statement = fields.Date(
        string='对账日期',
        default=fields.Date.context_today,
        required=True,
        tracking=True,
    )
    date_from = fields.Date(
        string='开始日期',
        required=True,
        tracking=True,
    )
    date_to = fields.Date(
        string='结束日期',
        required=True,
        tracking=True,
    )
    company_id = fields.Many2one(
        'res.company',
        string='公司',
        default=lambda self: self.env.company,
        required=True,
        tracking=True,
    )
    company_address = fields.Char(
        string='公司地址',
        compute='_compute_company_info',
        store=True,
    )
    company_phone = fields.Char(
        string='公司电话',
        compute='_compute_company_info',
        store=True,
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='客户',
        required=True,
        tracking=True,
    )
    partner_address = fields.Char(
        string='客户地址',
        compute='_compute_partner_info',
        store=True,
    )
    partner_phone = fields.Char(
        related='partner_id.phone',
        string='客户电话',
        readonly=True,
    )
    partner_contact = fields.Char(
        string='联系人',
        tracking=True,
    )
    line_ids = fields.One2many(
        'customer.statement.line',
        'statement_id',
        string='对账明细',
    )
    is_tax_included = fields.Boolean(
        string='含税',
        default=True,
        tracking=True,
    )
    tax_rate = fields.Float(
        string='税率(%)',
        default=13.0,
        tracking=True,
    )
    untaxed_amount = fields.Monetary(
        string='不含税金额',
        compute='_compute_amounts',
        store=True,
    )
    tax_amount = fields.Monetary(
        string='税额',
        compute='_compute_amounts',
        store=True,
    )
    total_amount = fields.Monetary(
        string='合计金额',
        compute='_compute_amounts',
        store=True,
    )
    currency_id = fields.Many2one(
        'res.currency',
        related='company_id.currency_id',
        string='币种',
    )
    note = fields.Text(
        string='备注',
        default='注：收到对账单后请一周内确认回签，否则视为无误同意。',
        tracking=True,
    )
    state = fields.Selection(
        [('draft', '草稿'), ('confirmed', '已对账')],
        string='状态',
        default='draft',
        tracking=True,
    )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('新建')) == _('新建'):
                vals['name'] = self.env['ir.sequence'].next_by_code('customer.statement') or _('新建')
        return super().create(vals_list)

    @api.depends('company_id')
    def _compute_company_info(self):
        for rec in self:
            partner = rec.company_id.partner_id
            address = ', '.join(filter(None, [
                partner.street, partner.street2, partner.city,
                partner.state_id.name, partner.zip, partner.country_id.name,
            ]))
            rec.company_address = address
            rec.company_phone = partner.phone or partner.mobile or ''

    @api.depends('partner_id')
    def _compute_partner_info(self):
        for rec in self:
            partner = rec.partner_id
            address = ', '.join(filter(None, [
                partner.street, partner.street2, partner.city,
                partner.state_id.name, partner.zip, partner.country_id.name,
            ]))
            rec.partner_address = address

    @api.depends('line_ids.quantity', 'line_ids.price_unit', 'is_tax_included', 'tax_rate')
    def _compute_amounts(self):
        for rec in self:
            rec.untaxed_amount = sum(line.quantity * line.price_unit for line in rec.line_ids)
            if rec.is_tax_included:
                rec.tax_amount = 0.0
                rec.total_amount = rec.untaxed_amount
            else:
                rec.tax_amount = rec.untaxed_amount * (rec.tax_rate or 0.0) / 100.0
                rec.total_amount = rec.untaxed_amount + rec.tax_amount

    def action_confirm(self):
        for rec in self:
            for line in rec.line_ids:
                if line.picking_id:
                    for move in line.picking_id.move_ids:
                        if move.state == 'done':
                            move.is_statemented = True
            orders = rec.line_ids.mapped('order_id')
            for order in orders:
                order._compute_statement_status()
        self.write({'state': 'confirmed'})

    def action_draft(self):
        for rec in self:
            for line in rec.line_ids:
                if line.picking_id:
                    for move in line.picking_id.move_ids:
                        if move.state == 'done':
                            move.is_statemented = False
            orders = rec.line_ids.mapped('order_id')
            for order in orders:
                order._compute_statement_status()
        self.write({'state': 'draft'})

    def action_export_excel(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_url',
            'url': '/customer_statement/excel/%s' % self.id,
            'target': 'self',
        }

    @api.ondelete(at_uninstall=False)
    def _unlink_if_draft(self):
        for rec in self:
            if rec.state != 'draft':
                raise UserError(_('只有草稿状态的对账单才能删除。'))
