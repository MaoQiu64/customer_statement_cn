from odoo import models, fields, api

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    statement_status = fields.Selection(
        [('pending', '待对账'), ('partial', '部分对账'), ('done', '完全对账')],
        string='对账状态',
        compute='_compute_statement_status',
        store=True,
    )

    @api.depends('order_line')
    def _compute_statement_status(self):
        for order in self:
            moves = order.order_line.mapped('move_ids').filtered(lambda m: 
                m.state == 'done' and m.picking_type_id.code == 'outgoing'
            )
            if not moves:
                order.statement_status = 'pending'
                continue

            total = len(moves)
            stated = len(moves.filtered('is_statemented'))
            if stated == 0:
                order.statement_status = 'pending'
            elif stated == total:
                order.statement_status = 'done'
            else:
                order.statement_status = 'partial'
