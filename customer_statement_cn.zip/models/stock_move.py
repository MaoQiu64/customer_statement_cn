from odoo import models, fields

class StockMove(models.Model):
    _inherit = 'stock.move'

    is_statemented = fields.Boolean(string='已对账', default=False)
