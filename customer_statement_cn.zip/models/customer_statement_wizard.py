from odoo import models, fields, api, _
from odoo.exceptions import UserError


class CustomerStatementWizard(models.TransientModel):
    _name = 'customer.statement.wizard'
    _description = '生成对账单向导'

    date_from = fields.Date(string='开始日期', required=True)
    date_to = fields.Date(
        string='结束日期',
        required=True,
        default=fields.Date.context_today,
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='客户',
        required=True,
    )
    is_tax_included = fields.Boolean(string='含税', default=True)
    tax_rate = fields.Float(string='税率(%)', default=13.0)
    line_ids = fields.One2many(
        'customer.statement.wizard.line',
        'wizard_id',
        string='发货单列表',
    )

    @api.onchange('date_from', 'date_to')
    def _onchange_dates(self):
        if self.date_from and self.date_to and self.date_from > self.date_to:
            return {
                'warning': {
                    'title': _('日期错误'),
                    'message': _('开始日期必须小于或等于结束日期。'),
                }
            }

    def _get_done_moves(self):
        """获取已完成的库存移动，通过 sale.order.line.move_ids 反向查询"""
        orders = self.env['sale.order'].search([
            ('partner_id', '=', self.partner_id.id),
            ('date_order', '>=', self.date_from),
            ('date_order', '<=', self.date_to),
        ])
        if not orders:
            return self.env['stock.move']

        order_lines = orders.mapped('order_line')
        if not order_lines:
            return self.env['stock.move']

        moves = order_lines.mapped('move_ids')

        return moves.filtered(lambda m: 
            m.state == 'done' and 
            m.picking_type_id.code == 'outgoing' and
            not m.is_statemented
        )

    def action_load_lines(self):
        self.ensure_one()
        self.line_ids.unlink()
        if not self.partner_id or not self.date_from or not self.date_to:
            raise UserError(_('请先选择客户和日期范围。'))
        if self.date_from > self.date_to:
            raise UserError(_('开始日期必须小于或等于结束日期。'))

        moves = self._get_done_moves()
        if not moves:
            raise UserError(_('所选条件下未找到未对账的已交货发货单。'))

        picking_moves = {}
        for move in moves:
            pid = move.picking_id.id
            if pid not in picking_moves:
                picking_moves[pid] = {'picking': move.picking_id, 'moves': []}
            picking_moves[pid]['moves'].append(move)

        vals = []
        for pid, data in picking_moves.items():
            picking = data['picking']
            order = picking.sale_id

            all_out = self.env['stock.move'].search([
                ('sale_line_id.order_id', '=', order.id),
                ('picking_type_id.code', '=', 'outgoing'),
            ])
            done_out = all_out.filtered(lambda m: m.state == 'done')
            if len(all_out) == len(done_out):
                delivery_status = '完全交付'
            else:
                delivery_status = '部分交付'

            stated = done_out.filtered(lambda m: m.is_statemented)
            if len(stated) == len(done_out):
                statement_status = '已对账'
            elif stated:
                statement_status = '部分对账'
            else:
                statement_status = '未对账'

            products = []
            for move in data['moves']:
                for ml in move.move_line_ids:
                    if ml.quantity > 0:
                        name = ml.product_id.display_name or ml.product_id.name
                        products.append('%s x %s' % (name, int(ml.quantity)))
            product_summary = '; '.join(products) if products else ''

            vals.append((0, 0, {
                'selected': True,
                'picking_id': picking.id,
                'picking_name': picking.name,
                'order_id': order.id,
                'order_name': order.name,
                'date_done': picking.date_done,
                'delivery_status': delivery_status,
                'statement_status': statement_status,
                'product_summary': product_summary,
            }))
        self.line_ids = vals
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'customer.statement.wizard',
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }

    def action_create_statement(self):
        self.ensure_one()
        selected = self.line_ids.filtered('selected')
        if not selected:
            raise UserError(_('请至少选择一个发货单。'))

        statement = self.env['customer.statement'].create({
            'date_from': self.date_from,
            'date_to': self.date_to,
            'partner_id': self.partner_id.id,
            'partner_contact': self.partner_id.name,
            'is_tax_included': self.is_tax_included,
            'tax_rate': self.tax_rate if not self.is_tax_included else 0.0,
        })

        line_vals = []
        for line in selected:
            picking = line.picking_id
            picking_name = line.picking_name or picking.name
            date_done_local = fields.Datetime.context_timestamp(self, picking.date_done)

            for move in picking.move_ids:
                if move.state == 'done' and move.sale_line_id:
                    for move_line in move.move_line_ids:
                        if move_line.quantity > 0:
                            sale_line = move.sale_line_id
                            product_name = sale_line.name or move_line.product_id.display_name or move_line.product_id.name
                            line_vals.append((0, 0, {
                                'date': date_done_local.date(),
                                'order_id': picking.sale_id.id,
                                'order_name': picking.sale_id.name,
                                'picking_id': picking.id,
                                'picking_name': picking_name,
                                'actual_picking_name': picking_name,
                                'product_id': move_line.product_id.id,
                                'product_name': product_name,
                                'quantity': move_line.quantity,
                                'price_unit': sale_line.price_unit or 0.0,
                                'note': '',
                            }))
        statement.line_ids = line_vals

        return {
            'type': 'ir.actions.act_window',
            'res_model': 'customer.statement',
            'res_id': statement.id,
            'view_mode': 'form',
            'target': 'current',
        }


class CustomerStatementWizardLine(models.TransientModel):
    _name = 'customer.statement.wizard.line'
    _description = '对账单向导发货单行'

    wizard_id = fields.Many2one(
        'customer.statement.wizard',
        required=True,
        ondelete='cascade',
    )
    selected = fields.Boolean(string='选择', default=True)
    picking_id = fields.Many2one('stock.picking', string='发货单')
    picking_name = fields.Char(string='发货单号')
    order_id = fields.Many2one('sale.order', string='销售订单', store=True)
    order_name = fields.Char(string='订单号')
    date_done = fields.Datetime(string='发货日期')
    delivery_status = fields.Char(string='交货状态')
    statement_status = fields.Char(string='对账状态')
    product_summary = fields.Char(string='产品摘要')
