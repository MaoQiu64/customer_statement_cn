from odoo import models, fields, api


class CustomerStatementLine(models.Model):
    _name = 'customer.statement.line'
    _description = '对账明细行'
    _order = 'date, picking_name, id'

    statement_id = fields.Many2one(
        'customer.statement',
        string='对账单',
        required=True,
        ondelete='cascade',
    )
    date = fields.Date(string='发货日期', required=True)
    order_id = fields.Many2one('sale.order', string='销售订单')
    order_name = fields.Char(string='订单号')
    picking_id = fields.Many2one('stock.picking', string='发货单')
    picking_name = fields.Char(string='发货单号')
    actual_picking_name = fields.Char(string='实际单号')
    product_id = fields.Many2one('product.product', string='产品')
    product_name = fields.Char(string='产品名称', required=True)
    quantity = fields.Float(string='数量', default=0.0)
    price_unit = fields.Float(string='单价', default=0.0)
    amount = fields.Monetary(
        string='金额',
        compute='_compute_amount',
        store=True,
    )
    note = fields.Char(string='备注')
    currency_id = fields.Many2one(
        'res.currency',
        related='statement_id.currency_id',
        string='币种',
    )

    @api.depends('quantity', 'price_unit')
    def _compute_amount(self):
        for line in self:
            line.amount = line.quantity * line.price_unit
