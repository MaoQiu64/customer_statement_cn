import io
from odoo import http
from odoo.http import request, content_disposition
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Side, Font


class CustomerStatementController(http.Controller):

    @http.route('/customer_statement/excel/<int:statement_id>', type='http', auth='user')
    def download_excel(self, statement_id, **kw):
        statement = request.env['customer.statement'].browse(statement_id)
        if not statement.exists():
            return request.not_found()

        wb = Workbook()
        ws = wb.active
        ws.title = "对账单"

        ws.column_dimensions['A'].width = 12
        ws.column_dimensions['B'].width = 14
        ws.column_dimensions['C'].width = 32
        ws.column_dimensions['D'].width = 12
        ws.column_dimensions['E'].width = 12
        ws.column_dimensions['F'].width = 16
        ws.column_dimensions['G'].width = 12

        thin = Side(style='thin', color='000000')
        thin_border = Border(left=thin, right=thin, top=thin, bottom=thin)
        center_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
        left_align = Alignment(horizontal='left', vertical='center', wrap_text=True)

        lines = statement.line_ids

        # ========== 准备数据 ==========
        date_groups = {}
        picking_groups = {}
        data_rows = []

        for idx, line in enumerate(lines):
            row_num = 9 + idx
            data_rows.append({
                'row': row_num,
                'date': line.date,
                'picking_name': line.actual_picking_name or line.picking_name or '',
                'product_name': line.product_name or '',
                'quantity': float(line.quantity or 0.0),
                'price_unit': float(line.price_unit or 0.0),
                'amount': float(line.amount or 0.0),
                'note': line.note or '',
            })

            dkey = line.date
            if dkey not in date_groups:
                date_groups[dkey] = [row_num, row_num]
            else:
                date_groups[dkey][1] = row_num

            pname = line.actual_picking_name or line.picking_name or ''
            if pname:
                if pname not in picking_groups:
                    picking_groups[pname] = [row_num, row_num]
                else:
                    picking_groups[pname][1] = row_num

        total_row = 9 + len(lines)
        payable_row = total_row + 1
        note_row = payable_row + 1

        # ========== 第1步：写入所有值（包括将被合并的单元格） ==========
        ws.cell(row=1, column=1, value=(statement.company_id.name or '') + ' 对账单')
        ws.cell(row=2, column=1, value='地址：%s' % (statement.company_address or ''))
        ws.cell(row=3, column=1, value='联系电话：%s' % (statement.company_phone or ''))
        df = statement.date_from.strftime('%Y年%m月%d日') if statement.date_from else ''
        dt = statement.date_to.strftime('%Y年%m月%d日') if statement.date_to else ''
        ws.cell(row=4, column=1, value='%s 至 %s 对账单' % (df, dt))
        ws.cell(row=5, column=1, value='收货单位：%s' % (statement.partner_id.name or ''))
        ws.cell(row=6, column=1, value='地址：%s' % (statement.partner_address or ''))
        contact_str = '联系人：%s    %s' % (statement.partner_contact or '', statement.partner_phone or '')
        ws.cell(row=7, column=1, value=contact_str)

        headers = ['日期', '发货单号', '产品名称', '数量', '单价', '金额', '备注']
        for col, h in enumerate(headers, 1):
            ws.cell(row=8, column=col, value=h)

        for dr in data_rows:
            row = dr['row']
            ws.cell(row=row, column=1, value=dr['date'].strftime('%m月%d日') if dr['date'] else '')
            ws.cell(row=row, column=2, value=dr['picking_name'])
            ws.cell(row=row, column=3, value=dr['product_name'])
            ws.cell(row=row, column=4, value=dr['quantity'])
            ws.cell(row=row, column=5, value=dr['price_unit'])
            ws.cell(row=row, column=6, value=dr['amount'])
            ws.cell(row=row, column=7, value=dr['note'])

        ws.cell(row=total_row, column=1, value='合计')
        ws.cell(row=total_row, column=6, value=float(statement.total_amount or 0.0))

        ws.cell(row=payable_row, column=1, value='应付货款：')
        if statement.is_tax_included:
            tax_str = '【含税】'
            ws.cell(row=payable_row, column=3, value='¥:%.2f %s' % (float(statement.total_amount or 0.0), tax_str))
        else:
            tax_str = '【不含税】'
            detail = '不含税金额：¥%.2f  税额：¥%.2f  含税总价：¥%.2f %s' % (
                float(statement.untaxed_amount or 0.0),
                float(statement.tax_amount or 0.0),
                float(statement.total_amount or 0.0),
                tax_str,
            )
            ws.cell(row=payable_row, column=3, value=detail)

        ws.cell(row=note_row, column=1, value=statement.note or '')

        # ========== 第2步：设置所有样式（此时所有单元格都是普通 Cell） ==========
        # 标题行 (1-7)
        for r in range(1, 8):
            for c in range(1, 8):
                cell = ws.cell(row=r, column=c)
                cell.border = thin_border
                cell.font = Font(name='微软雅黑')
                if r == 1:
                    cell.font = Font(size=14, bold=True, name='微软雅黑')
                    cell.alignment = center_align
                elif r in (2, 3, 4):
                    cell.alignment = center_align
                else:
                    cell.alignment = left_align
        ws.row_dimensions[1].height = 30

        # 表头 (8)
        for c in range(1, 8):
            cell = ws.cell(row=8, column=c)
            cell.border = thin_border
            cell.alignment = center_align
            cell.font = Font(bold=True, name='微软雅黑')

        # 数据行
        for dr in data_rows:
            row = dr['row']
            for c in range(1, 8):
                cell = ws.cell(row=row, column=c)
                cell.border = thin_border
                cell.font = Font(name='微软雅黑')
                if c in (1, 2, 4, 5, 6):
                    cell.alignment = center_align
                else:
                    cell.alignment = left_align

        # 合计行
        for c in range(1, 8):
            cell = ws.cell(row=total_row, column=c)
            cell.border = thin_border
            cell.font = Font(bold=True, name='微软雅黑')
            cell.alignment = center_align

        # 应付货款行
        for c in range(1, 8):
            cell = ws.cell(row=payable_row, column=c)
            cell.border = thin_border
            cell.font = Font(name='微软雅黑')
            cell.alignment = left_align
        ws.cell(row=payable_row, column=1).font = Font(bold=True, name='微软雅黑')

        # 备注行
        for c in range(1, 8):
            cell = ws.cell(row=note_row, column=c)
            cell.border = thin_border
            cell.font = Font(name='微软雅黑')
            cell.alignment = left_align

        # ========== 第3步：最后执行合并（此时所有单元格已有完整样式） ==========
        # 标题行合并
        for r in range(1, 8):
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=7)

        # 日期列合并
        for dkey, (start, end) in date_groups.items():
            if start != end:
                ws.merge_cells(start_row=start, start_column=1, end_row=end, end_column=1)

        # 发货单号列合并
        for pname, (start, end) in picking_groups.items():
            if start != end:
                ws.merge_cells(start_row=start, start_column=2, end_row=end, end_column=2)

        # 合计行合并
        ws.merge_cells(start_row=total_row, start_column=1, end_row=total_row, end_column=5)
        # 应付货款行合并
        ws.merge_cells(start_row=payable_row, start_column=1, end_row=payable_row, end_column=2)
        ws.merge_cells(start_row=payable_row, start_column=3, end_row=payable_row, end_column=7)
        # 备注行合并
        ws.merge_cells(start_row=note_row, start_column=1, end_row=note_row, end_column=7)

        # ========== 保存 ==========
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)

        filename = '对账单_%s.xlsx' % (statement.name or '导出')
        return request.make_response(
            output.read(),
            headers=[
                ('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
                ('Content-Disposition', content_disposition(filename)),
            ],
        )
