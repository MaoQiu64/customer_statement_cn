{
    "name": "客户对账单",
    "version": "18.0.8.0.0",
    "category": "销售",
    "summary": "根据已交货的销售订单生成客户对账单",
    "description": """
客户对账单
==========
根据已完成的出库单生成客户对账单。

功能：
- 按时间段和客户筛选
- 只加载有已完成交货的销售订单
- 手动勾选需要对账的发货单
- 自动展开发货单下已完成交货的产品明细
- 支持含税/不含税计算
- 销售订单对账单状态跟踪
- 导出Excel（格式完全符合传统对账单样式）
- 菜单位于销售模块下
    """,
    "author": "定制开发",
    "depends": ["sale", "sale_stock", "mail"],
    "data": [
        "security/ir.model.access.csv",
        "data/sequence.xml",
        "views/sale_order_views.xml",
        "views/customer_statement_views.xml",
        "report/customer_statement_templates.xml",
        "report/customer_statement_report.xml",
    ],
    "installable": True,
    "application": False,
    "license": "LGPL-3",
}